Assignment 5 – Heaps
Spring 2026
Due: Tuesday, April 28 11:59 pm
To-do
Download the base code Heap for the array implementation of Heaps that we covered
in class from D2L. Using this base code complete the following tasks.
Task 1: Implement heapifyDown() function that bubbles down the replacement
node after deletion.
Task 2: Implement buildH() function to build a max heap from an array using
Floyd’s Optimization.
Task 3: Implement replace() function to replace an existing value in the heap
with a new one.
Task 4: Implement heapSort() function to sort.
Task 5: Implement switchMinMax() function to convert a Max heap into a Min
heap and vice versa. Note that you’ll also need to implement the helper function
heapifyDownMin().
Total Points (100)
- Code runs and works as expected – Task 1: 10 points
- Code runs and works as expected – Task 2: 20 points
- Code runs and works as expected - Task 3: 20 points
- Code runs and works as expected - Task 4: 25 points
- Code runs and works as expected - Task 5: 25 points
- Proper commenting: 5 points
- Available on GitHub: 5 points
Deliverables:
- A zipped folder named A5 that contains all the files submitted to D2L dropbox
o C++ files and header files
o README.txt file
o A screenshot showing the functions work.
- Published to GitHub under the folder where you added me as a collaborator.Assignment 5 – Heaps
Spring 2026
Due: Tuesday, April 28 11:59 pm
To-do
Download the base code Heap for the array implementation of Heaps that we covered
in class from D2L. Using this base code complete the following tasks.
Task 1: Implement heapifyDown() function that bubbles down the replacement
node after deletion.
Task 2: Implement buildH() function to build a max heap from an array using
Floyd’s Optimization.
Task 3: Implement replace() function to replace an existing value in the heap
with a new one.
Task 4: Implement heapSort() function to sort.
Task 5: Implement switchMinMax() function to convert a Max heap into a Min
heap and vice versa. Note that you’ll also need to implement the helper function
heapifyDownMin().
Total Points (100)
- Code runs and works as expected – Task 1: 10 points
- Code runs and works as expected – Task 2: 20 points
- Code runs and works as expected - Task 3: 20 points
- Code runs and works as expected - Task 4: 25 points
- Code runs and works as expected - Task 5: 25 points
- Proper commenting: 5 points
- Available on GitHub: 5 points
Deliverables:
- A zipped folder named A5 that contains all the files submitted to D2L dropbox
o C++ files and header files
o README.txt file
o A screenshot showing the functions work.
- Published to GitHub under the folder where you added me as a collaborator.