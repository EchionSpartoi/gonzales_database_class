#include "heap.h"

HEAP::HEAP(int size) {
    isMaxHeap = true;
    capacity = size;
    heapSize = 0;
    array = new int[capacity];
}

HEAP::~HEAP() {
    delete[] array;
}

int HEAP::leftChild(int index) {
    return 2*index + 1;
}
int HEAP::rightChild(int index) {
    return 2*index + 2;
}
int HEAP::parent(int index) {
    return (index - 1) / 2;
}

void HEAP::insertH(int data) {
    if (heapSize == capacity) {
        cout << "Heap overflow - can't insert"<< endl;
        return;
    }

    array[heapSize] = data;
    heapifyUp(heapSize);
    heapSize++;
}

void HEAP::heapifyUp(int index) {
    while(index != 0 && array[parent(index)] < array[index]) {
        swap(array[parent(index)], array[index]);
        index = parent(index);
    }
}

int HEAP::peek() {
    if (heapSize <= 0) {
        cout << "Heap is empty" << endl;
        return -1;
    }

    return array[0];
}

void HEAP::deleteMax() {
    if (heapSize <= 0) {
        cout << "Heap is empty - nothing to delete" << endl;
        return;
    }

    if (heapSize == 1) {
        heapSize--;
        return;
    }

    array[0] = array[heapSize - 1];
    heapSize--;

    heapifyDown(0);
}

void HEAP::deleteH(int data) {
    int index = -1;

    // search for data - linear search :( O(n)
    for (int i = 0; i < heapSize; i++) {
        if (array[i] == data) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        cout << "Element not found - can't delete"  << endl;
        return;
    }

    array[index] = array[heapSize - 1];
    heapSize--;

    heapifyDown(index);
}

// Reference pattern for heapify down (iterative variant):
// https://github.com/wangsibovictor/fora/blob/b1526fd66512afe16652d3256e60bef04f981715/heap.h#L76
// Adapted to recursive max-heapify for integer array implementation.
//action item 1
void HEAP::heapifyDown(int index) {
    int largest = index;
    int left = leftChild(index);
    int right = rightChild(index);
    
    // Compare with left child
    if (left < heapSize && array[left] > array[largest]) {
        largest = left;
    }
    
    // Compare with right child
    if (right < heapSize && array[right] > array[largest]) {
        largest = right;
    }
    
    // If current node is not largest, swap and continue
    if (largest != index) {
        swap(array[index], array[largest]);
        heapifyDown(largest);
    }
}

//algorithm for building a max heap
// 1. Copy array elements to heap array
// 2. Set heapSize to n
// 3. Find last non-leaf node: (n/2) - 1
// 4. For i from lastNonLeaf down to 0:
//    - Call heapifyDown(i)
// 5. Heap is now built
 
//action item 2
void HEAP::buildH(int arr[], int n) {
    // Copy array to heap
    for (int i = 0; i < n; i++) {
        array[i] = arr[i];
    }
    heapSize = n;
    
    // Start from last non-leaf node
    int lastNonLeaf = (heapSize / 2) - 1;
    
    // Heapify all non-leaf nodes
    for (int i = lastNonLeaf; i >= 0; i--) {
        heapifyDown(i);
    }
}

//algorithm. 
// 1. Search for oldData in array (O(n) linear search)
// 2. If not found, print error and return
// 3. Replace oldData with newData at found index
// 4. If newData > oldData: heapifyUp (might need to bubble up)
// 5. If newData < oldData: heapifyDown (might need to bubble down)

//action item 3
void HEAP::replace(int oldData, int newData) {
    int index = -1;
    
    // Search for oldData
    for (int i = 0; i < heapSize; i++) {
        if (array[i] == oldData) {
            index = i;
            break;
        }
    }
    
    if (index == -1) {
        cout << "Element not found - can't replace" << endl;
        return;
    }
    
    // Replace the value
    array[index] = newData;
    
    // Restore heap property
    if (newData > oldData) {
        heapifyUp(index);
    } else {
        heapifyDown(index);
    }
}

//algorithm 
    // 1. Build max heap from array
    // 2. For i from n-1 down to 1:
    // - Swap array[0] (max) with array[i]
    // - Reduce heap size by 1
    // - heapifyDown(0) to restore heap property
    // 3. Array is now sorted in ascending order

//action item 4
void HEAP::heapSort(int arr[], int n) {
    // Build heap from array
    buildH(arr, n);
    
    // Extract elements one by one
    for (int i = n - 1; i > 0; i--) {
        // Swap current root with last element
        swap(array[0], array[i]);
        
        // Reduce heap size
        heapSize--;
        
        // Heapify root
        heapifyDown(0);
    }
    
    // Copy sorted array back to input array
    for (int i = 0; i < n; i++) {
        arr[i] = array[i];
    }
}

void HEAP::printHeap(int index, int depth) {
    if (index >= heapSize)
        return;

    printHeap(rightChild(index), depth + 1);

    for (int i = 0; i < depth; i++) {
        cout << "  "; // indentation based on depth
    }

    cout << array[index] << endl;

    printHeap(leftChild(index), depth + 1);
}


// Reference pattern for min-heapify/down-heap:
// https://github.com/unbracedm56/DSA-Lab-Questions/blob/18d1defb614c9ed095fd4342634517cead3b0066/Lab%208/3.c#L36

void HEAP::heapifyDownMin(int index) {
    int smallest = index;
    int left = leftChild(index);
    int right = rightChild(index);
    
    // Find smallest among node and children
    if (left < heapSize && array[left] < array[smallest]) {
        smallest = left;
    }
    if (right < heapSize && array[right] < array[smallest]) {
        smallest = right;
    }
    
    // If current node is not smallest, swap and continue
    if (smallest != index) {
        swap(array[index], array[smallest]);
        heapifyDownMin(smallest);
    }
}

// AI-assisted implementation note:
// OpenAI. "ChatGPT" (GPT-based language model), conversation support for HEAP::switchMinMax()
// Accessed: April 26, 2026.
void HEAP::switchMinMax() {
    isMaxHeap = !isMaxHeap;
    
    // Rebuild heap with new type
    int lastNonLeaf = (heapSize / 2) - 1;
    for (int i = lastNonLeaf; i >= 0; i--) {
        if (isMaxHeap) {
            heapifyDown(i);
        } else {
            heapifyDownMin(i);
        }
    }
}