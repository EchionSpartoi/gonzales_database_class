/*
AI assistance provided for implementation of Prim's, Kruskal's, and Dijkstra's algorithms.
Algorithm design and understanding provided by student.
MLA Citation:
"Implementation of Prim's, Kruskal's, and Dijkstra's graph algorithms." Cascade (AI Assistant),
Cognition, 6 May 2026.
*/

#include "graph.h"
#include <vector>
#include <tuple>

Graph::Graph(int maxV)
{
    maxVertices = maxV;
    numVertices = 0;
    vertices = nullptr;

    visited = new bool[maxVertices] {false};

    parent = new int[maxVertices];
    rank = new int[maxVertices] {0};
    for(int i = 0; i < maxVertices; i++){
        parent[i] = i;  // Each vertex is its own parent initially
    }

    adjMatrix = new int*[maxVertices]; // a pointer of rows
    // each int* stores a row
    for(int i = 0; i < maxVertices; i++){
        adjMatrix[i] = new int[maxVertices];
        for (int j = 0; j < maxVertices; j++)
            adjMatrix[i][j] = 0;
    }
}

Graph::~Graph()
{
    delete[] visited;
    delete[] parent;
    delete[] rank;

    for(int i = 0; i < maxVertices; i++)
        delete[] adjMatrix[i];

    delete[] adjMatrix;

    vertex* tempVertex;
    while(vertices)
    {
        edge* tempEdge;
        // free the memory of the neighbor list of that vertex
        while(vertices->aHead)
        {
            tempEdge = vertices->aHead;
            vertices->aHead = vertices->aHead->eNext;
            delete tempEdge;
        }
        // free that vertex itself
        tempVertex = vertices;
        vertices = vertices->vNext;
        delete tempVertex;
    }
}

void Graph::addVertex(char data)
{
    if(numVertices >= maxVertices)
    {
        cout << "Max number of vertices reached. Can't add!" << endl;
        return;
    }

    vertex* newVertex = new vertex;
    newVertex->data = data;
    newVertex->vNext = vertices; // add at the beg of the vertices list
    vertices = newVertex; // make it the new head of the vertex list
    newVertex->aHead = nullptr;

    numVertices++;
}

void Graph::addEdge(char src, char dest, int weight)
{
    vertex* srcVertex = vertices;
    vertex* destVertex = vertices;

    // find src and dest vertices
    while(srcVertex && srcVertex->data != src)
    {
        srcVertex = srcVertex->vNext;
    }
    while(destVertex && destVertex->data != dest)
    {
        destVertex = destVertex->vNext;
    }

    if(!srcVertex || !destVertex)
    {
        cout << "Vertices not found - can't add an edge" << endl;
        return;
    }

    // Adj list - undirected graph
    edge* newEdge = new edge;
    newEdge->dest = destVertex;
    newEdge->weight = weight;
    newEdge->eNext = srcVertex->aHead;
    srcVertex->aHead = newEdge;

    // Since undirected, add the reverse edge as well
    newEdge = new edge;
    newEdge->dest = srcVertex;
    newEdge->weight = weight;
    newEdge->eNext = destVertex->aHead;
    destVertex->aHead = newEdge;

    // Adj Matrix
    int srcIndex = srcVertex->data - 'A';
    int destIndex = destVertex->data - 'A';
    adjMatrix[srcIndex][destIndex] = weight;
    adjMatrix[destIndex][srcIndex] = weight;
}

void Graph::removeVertex(char data)
{
    // find the vertex
    vertex* temp = vertices;
    vertex* prev = nullptr;

    while(temp && temp->data != data)
    {
        prev = temp;
        temp = temp->vNext;
    }
    
    if(!temp)
    {
        cout << "Vertex not found - can't remove" << endl;
        return;
    }

    // remove that vertex from the adj list of all other vertices
    for(vertex* v = vertices; v != nullptr; v = v->vNext)
    {
        edge* e = v->aHead;
        edge* prevEdge = nullptr;
        while(e)
        {
            if(e->dest->data == data)
            {
                if(prevEdge)
                    prevEdge->eNext = e->eNext;
                else
                    v->aHead = e->eNext;
                delete e;
                break;
            }
            prevEdge = e;
            e = e->eNext;
        }
    }

    // remove the vertex
    if(prev)
        prev->vNext = temp->vNext;
    else
        vertices = temp->vNext;

    delete temp;

    // Adj matrix
    int index = temp->data - 'A';
    for(int i = 0; i < maxVertices; i++)
    {
        adjMatrix[i][index] = 0;
        adjMatrix[index][i] = 0;
    }

    numVertices--;
}

void Graph::displayList()
{
    for(vertex* v = vertices; v != nullptr; v = v->vNext)
    {
        cout << v->data << " -> ";
        for(edge* e = v->aHead; e != nullptr; e = e->eNext)
        {
            cout << e->dest->data << " (" << e->weight << ") -> ";
        }
        cout << "null" << endl;
    }
    cout << endl;
}

void Graph::displayMatrix()
{
    cout << "     ";
    for(int i = 0; i < maxVertices; i++)
    {
        cout << setw(3) << char('A' + i) << " "; // column headers
    }
    cout << endl;
    cout << "   ";
    
    for(int i = 0; i < maxVertices; i++)
    {
        cout << "-----";
    }
    cout << endl;

    for(int i = 0; i < maxVertices; i++)
    {
        cout << setw(3) << char('A' + i) << " |"; // row header
        for(int j = 0; j < maxVertices; j++)
        {
            cout << setw(3) << adjMatrix[i][j] << " ";
        }
        cout << endl;
    }
}

void Graph::removeEdge(char src, char dest)
{
    vertex* srcVertex = vertices;
    vertex* destVertex = vertices;

    // find src and dest vertices
    while(srcVertex && srcVertex->data != src)
    {
        srcVertex = srcVertex->vNext;
    }
    while(destVertex && destVertex->data != dest)
    {
        destVertex = destVertex->vNext;
    }

    if(!srcVertex || !destVertex)
    {
        cout << "Vertices not found - can't remove edge" << endl;
        return;
    }

    // Adj Matrix
    int srcIndex = srcVertex->data - 'A';
    int destIndex = destVertex->data - 'A';
    adjMatrix[srcIndex][destIndex] = 0;
    adjMatrix[destIndex][srcIndex] = 0;

    // Remove from adjacency list (undirected graph)
    edge* prev = nullptr;
    edge* curr = srcVertex->aHead;

    while(curr && curr->dest != destVertex)
    {
        prev = curr;
        curr = curr->eNext;
    }
    
    if(curr)
    {
        if(prev)
        {
            prev->eNext = curr->eNext;
        }
        else
        {
            srcVertex->aHead = curr->eNext;
        }
        delete curr;
    }

    // Remove the reverse edge as well
    prev = nullptr;
    curr = destVertex->aHead;

    while(curr && curr->dest != srcVertex)
    {
        prev = curr;
        curr = curr->eNext;
    }
    
    if(curr)
    {
        if(prev)
        {
            prev->eNext = curr->eNext;
        }
        else
        {
            destVertex->aHead = curr->eNext;
        }
        delete curr;
    }
}
void Graph::bfsL(char start){
    // Guard against empty graph
    if(vertices == nullptr) {
        cout << "Graph is empty" << endl;
        return;
    }

    //we need a place to start
    //a way to track what we already visited
    //a way to process vertices level by level
    //the actual loop if there is still something to process. 

    vertex* startVertex = vertices;
    int startIndex = startVertex->data - 'A';
    
    // Mark the starting vertex as visited
    visited[startIndex] = true;
    
    // Enqueue the starting vertex
    queue<vertex*> q;
    q.push(startVertex);
    
    // Process vertices as long as the queue is not empty
    while(!q.empty())
    {
        // Dequeue the current vertex
        vertex* currentVertex = q.front();
        q.pop();
        
        // Print the current vertex
        cout << currentVertex->data << " ";
        
        // Traverse the current vertex's edge list
        for(edge* e = currentVertex->aHead; e != nullptr; e = e->eNext)
        {
            // If neighbor hasn't been visited
            if(!visited[e->dest->data - 'A'])
            {
                // Mark neighbor as visited
                visited[e->dest->data - 'A'] = true;
                
                // Enqueue the neighbor
                q.push(e->dest);
            }
        }
    }
}

void Graph::bfsM(char start){
    if(vertices == nullptr) return;

    // reset visited
    for(int i = 0; i < maxVertices; i++) {
        visited[i] = false;
    }

    // set startVertex and startIndex
    vertex* startVertex = vertices;
    int startIndex = startVertex->data - 'A';
    
    // mark start visited
    visited[startIndex] = true;
    
    // enqueue start
    queue<vertex*> q;
    q.push(startVertex);

    while(!q.empty())
    {
        vertex* currentVertex = q.front();
        q.pop();
        cout << currentVertex->data << " ";

        // THIS is where your matrix loop goes
        int currIndex = currentVertex->data - 'A';
        for(int i = 0; i < maxVertices; i++)
        {
            if(adjMatrix[currIndex][i] != 0 && !visited[i])
            {
                visited[i] = true;
                vertex* neighbor = vertices;
                while(neighbor && neighbor->data != 'A' + i)
                    neighbor = neighbor->vNext;
                if(neighbor)
                    q.push(neighbor);
            }
        }
    }
}

void Graph::dfsL(char start){
    // Guard against empty graph
    if(vertices == nullptr) {
        cout << "Graph is empty" << endl;
        return;
    }

    // Reset visited array
    for(int i = 0; i < maxVertices; i++) {
        visited[i] = false;
    }

    // Start DFS from the first vertex

    vertex* startVertex = vertices;
    int startIndex = startVertex->data - 'A';
    
    // Mark the starting vertex as visited
    visited[startIndex] = true;
    
    // Enqueue the starting vertex
    queue<vertex*> q;
    q.push(startVertex);
    
    // Process vertices as long as the queue is not empty
    while(!q.empty())
    {
        // Dequeue the current vertex
        vertex* currentVertex = q.front();
        q.pop();
        
        // Print the current vertex
        cout << currentVertex->data << " ";
        
        // Traverse the current vertex's edge list
        for(edge* e = currentVertex->aHead; e != nullptr; e = e->eNext)
        {
            // If neighbor hasn't been visited
            if(!visited[e->dest->data - 'A'])
            {
                // Mark neighbor as visited
                visited[e->dest->data - 'A'] = true;
                
                // Enqueue the neighbor
                q.push(e->dest);
            }
        }
    }
}

void Graph::dfsM(char start){
    // Reset visited array
    for(int i = 0; i < maxVertices; i++) {
        visited[i] = false;
    }

    // Start DFS from the first vertex
    vertex* startVertex = vertices;
    int startIndex = startVertex->data - 'A';
    
    // Use a stack for DFS
    stack<vertex*> dfsStack;
    
    // Push the starting vertex onto the stack
    dfsStack.push(startVertex);
    visited[startIndex] = true;
    
    while(!dfsStack.empty()) {
        // Pop the top vertex from the stack
        vertex* currentVertex = dfsStack.top();
        dfsStack.pop();
        
        // Print the current vertex
        cout << currentVertex->data << " ";
        
        // Find the index of the current vertex
        int currIndex = currentVertex->data - 'A';
        
        // Visit all adjacent vertices using the adjacency matrix
        for(int i = 0; i < maxVertices; i++) {
            // If there is an edge and the vertex hasn't been visited
            if(adjMatrix[currIndex][i] != 0 && !visited[i]) {
                visited[i] = true;
                
                // Find the vertex object corresponding to the index
                vertex* neighbor = vertices;
                while(neighbor && neighbor->data != 'A' + i)
                    neighbor = neighbor->vNext;
                
                // Push the neighbor onto the stack
                if(neighbor)
                    dfsStack.push(neighbor);
            }
        }
    }
}


void Graph::detectCycle(){
    // Step 1: Check if graph is empty
    if(vertices == nullptr) {
        cout << "Graph is empty - no cycle" << endl;
        return;
    }

    // Step 2: Reset visited array to track visited vertices
    for(int i = 0; i < maxVertices; i++) {
        visited[i] = false;
    }

    // Step 3: For each unvisited vertex, start DFS traversal
    for(vertex* v = vertices; v != nullptr; v = v->vNext) {
        if(!visited[v->data - 'A']) {
            // Step 4: In DFS, if we encounter a visited vertex that's not the parent, cycle exists
            if(detectCycleUtil(v, nullptr)) {
                cout << "Cycle detected in graph" << endl;
                return;
            }
        }
    }

    // Step 5: Return true if cycle found, false otherwise
    cout << "No cycle detected in graph" << endl;
}

bool Graph::detectCycleUtil(vertex* v, vertex* parent) {
    // Mark the current vertex as visited
    visited[v->data - 'A'] = true;
    
    // Recursively visit all adjacent vertices
    for(edge* e = v->aHead; e != nullptr; e = e->eNext) {
        // If the adjacent vertex hasn't been visited yet
        if(!visited[e->dest->data - 'A']) {
            // Recursively check for cycles from that vertex
            if(detectCycleUtil(e->dest, v)) {
                return true;
            }
        } 
        // If the adjacent vertex has been visited and is not the parent
        else if(e->dest != parent) {
            // We've found a back edge, indicating a cycle
            return true;
        }
    }
    // No cycles found from this vertex
    return false;
}

void Graph::dfsLRecursive(vertex* v) {
    // Traverse all adjacent vertices
    for(edge* e = v->aHead; e != nullptr; e = e->eNext) {
        // If the adjacent vertex hasn't been visited yet
        if(!visited[e->dest->data - 'A']) {
            // Mark it as visited
            visited[e->dest->data - 'A'] = true;
            // Print the vertex data
            cout << e->dest->data << " ";
            // Recursively visit its neighbors
            dfsLRecursive(e->dest);
        }
    }
}

// Prim's Algorithm - Step by Step:
// 1. Reset visited array to track visited vertices
// 2. Find the starting vertex in the graph
// 3. Create a min-heap priority queue to store edges (weight, source, destination)
// 4. Initialize variables to store MST edges and total cost
// 5. Mark the starting vertex as visited
// 6. Push all edges from the starting vertex into the priority queue
// 7. Loop while queue is not empty and MST has fewer than V-1 edges:
//    a. Pop the cheapest edge from the queue
//    b. If the destination node is already visited, ignore it (prevents cycles)
//    c. If not visited:
//       - Mark the destination as visited
//       - Add the edge weight to total cost
//       - Store the edge in MST list
//       - Push all edges from the new node to unvisited neighbors into the queue
// 8. Print the MST edges and total cost
void Graph::prim(char start) {
    // Reset visited array
    for(int i = 0; i < maxVertices; i++) {
        visited[i] = false;
    }

    // Find starting vertex
    vertex* startVertex = vertices;
    while(startVertex && startVertex->data != start) {
        startVertex = startVertex->vNext;
    }

    if(!startVertex) {
        cout << "Starting vertex not found" << endl;
        return;
    }

    // Min-heap priority queue: (weight, source, destination)
    // Using greater to make it a min-heap
    priority_queue<tuple<int, char, char>, vector<tuple<int, char, char>>, greater<tuple<int, char, char>>> pq;

    // Store MST edges
    vector<tuple<int, char, char>> mstEdges;
    int totalCost = 0;

    // Mark start as visited and add its edges
    visited[startVertex->data - 'A'] = true;
    for(edge* e = startVertex->aHead; e != nullptr; e = e->eNext) {
        pq.push(make_tuple(e->weight, startVertex->data, e->dest->data));
    }

    // Build MST
    while(!pq.empty() && mstEdges.size() < numVertices - 1) {
        tuple<int, char, char> edgeTuple = pq.top();
        pq.pop();

        int weight = get<0>(edgeTuple);
        char src = get<1>(edgeTuple);
        char dest = get<2>(edgeTuple);

        // Find destination vertex
        vertex* destVertex = vertices;
        while(destVertex && destVertex->data != dest) {
            destVertex = destVertex->vNext;
        }

        // If destination not visited, add to MST
        if(destVertex && !visited[destVertex->data - 'A']) {
            visited[destVertex->data - 'A'] = true;
            mstEdges.push_back(edgeTuple);
            totalCost += weight;

            // Add all edges from the new vertex
            for(edge* e = destVertex->aHead; e != nullptr; e = e->eNext) {
                if(!visited[e->dest->data - 'A']) {
                    pq.push(make_tuple(e->weight, destVertex->data, e->dest->data));
                }
            }
        }
    }

    // Print MST
    cout << "Minimum Spanning Tree (Prim's):" << endl;
    for(const auto& edgeTuple : mstEdges) {
        cout << "Edge " << get<1>(edgeTuple) << "-" << get<2>(edgeTuple) << " (weight " << get<0>(edgeTuple) << ")" << endl;
    }
    cout << "Total Cost: " << totalCost << endl;
}

int Graph::find(int x) {
    if (parent[x] != x)
        parent[x] = find(parent[x]);  // Path compression
    return parent[x];
}

void Graph::unionSets(int x, int y) {
    int rootX = find(x);
    int rootY = find(y);

    if (rootX != rootY) {
        // Union by rank
        if (rank[rootX] < rank[rootY])
            parent[rootX] = rootY;
        else if (rank[rootX] > rank[rootY])
            parent[rootY] = rootX;
        else {
            parent[rootY] = rootX;
            rank[rootX]++;
        }
    }
}

// Kruskal's Algorithm - Step by Step:
// 1. Collect all edges from the graph into a list (weight, source, destination)
// 2. Sort the edge list by weight from smallest to largest
// 3. Reset DSU arrays (each vertex is its own parent initially)
// 4. Initialize variables to store MST edges and total cost
// 5. Loop through sorted edges one by one
// 6. For each edge, use DSU to check if the two vertices are already connected
// 7. If not connected (different sets):
//    a. Add the edge to the MST
//    b. Add the edge weight to total cost
//    c. Union the two sets (merge the groups)
// 8. If already connected (same set), skip the edge (would create a cycle)
// 9. Stop when MST has V-1 edges
// 10. Print the MST edges and total cost
void Graph::kruskal() {
    // Collect all edges from the graph
    vector<tuple<int, char, char>> edges;

    for(vertex* v = vertices; v != nullptr; v = v->vNext) {
        for(edge* e = v->aHead; e != nullptr; e = e->eNext) {
            // Only add edge if source < destination to avoid duplicates (undirected graph)
            if(v->data < e->dest->data) {
                edges.push_back(make_tuple(e->weight, v->data, e->dest->data));
            }
        }
    }

    // Sort edges by weight
    sort(edges.begin(), edges.end());

    // Reset DSU arrays
    for(int i = 0; i < maxVertices; i++) {
        parent[i] = i;
        rank[i] = 0;
    }

    // Store MST edges and total cost
    vector<tuple<int, char, char>> mstEdges;
    int totalCost = 0;

    // Process edges in sorted order
    for(const auto& edgeTuple : edges) {
        if(mstEdges.size() >= numVertices - 1) {
            break;  // MST complete
        }

        int weight = get<0>(edgeTuple);
        char src = get<1>(edgeTuple);
        char dest = get<2>(edgeTuple);

        int srcIndex = src - 'A';
        int destIndex = dest - 'A';

        // Check if vertices are in different sets
        if(find(srcIndex) != find(destIndex)) {
            // Add edge to MST
            mstEdges.push_back(edgeTuple);
            totalCost += weight;
            // Merge the sets
            unionSets(srcIndex, destIndex);
        }
        // If same set, skip (would create cycle)
    }

    // Print MST
    cout << "Minimum Spanning Tree (Kruskal's):" << endl;
    for(const auto& edgeTuple : mstEdges) {
        cout << "Edge " << get<1>(edgeTuple) << "-" << get<2>(edgeTuple) << " (weight " << get<0>(edgeTuple) << ")" << endl;
    }
    cout << "Total Cost: " << totalCost << endl;
}

// Dijkstra's Algorithm - Step by Step:
// 1. Set distance to start node to 0, all other nodes to infinity
// 2. Push (0, start node) into min-heap priority queue
// 3. While queue is not empty:
//    a. Pop the node with the smallest distance
//    b. For each neighbor of that node:
//       - Calculate new distance = current distance + edge weight
//       - If new distance < neighbor's current known distance:
//         * Update neighbor's distance
//         * Push (new distance, neighbor) into priority queue
// 4. When queue is empty, distance array holds shortest path from start to every node
// 5. Print the shortest distances to all vertices
void Graph::dijkstra(char start) {
    // Initialize distance array with infinity
    const int INF = 999999;
    int* dist = new int[maxVertices];
    for(int i = 0; i < maxVertices; i++) {
        dist[i] = INF;
    }

    // Find starting vertex
    vertex* startVertex = vertices;
    while(startVertex && startVertex->data != start) {
        startVertex = startVertex->vNext;
    }

    if(!startVertex) {
        cout << "Starting vertex not found" << endl;
        delete[] dist;
        return;
    }

    // Set distance to start node to 0
    int startIndex = startVertex->data - 'A';
    dist[startIndex] = 0;

    // Min-heap priority queue: (distance, vertex)
    // Using greater to make it a min-heap (std::priority_queue is max-heap by default)
    priority_queue<pair<int, vertex*>, vector<pair<int, vertex*>>, greater<pair<int, vertex*>>> pq;

    // Push (0, start node) into priority queue
    pq.push(make_pair(0, startVertex));

    // Process vertices
    while(!pq.empty()) {
        // Pop node with smallest distance
        pair<int, vertex*> current = pq.top();
        pq.pop();

        int currentDist = current.first;
        vertex* currentVertex = current.second;

        // For each neighbor of current node
        for(edge* e = currentVertex->aHead; e != nullptr; e = e->eNext) {
            int neighborIndex = e->dest->data - 'A';

            // Calculate new distance = current distance + edge weight
            int newDist = currentDist + e->weight;

            // If new distance < neighbor's current known distance, update it
            if(newDist < dist[neighborIndex]) {
                dist[neighborIndex] = newDist;
                // Push (new distance, neighbor) into priority queue
                pq.push(make_pair(newDist, e->dest));
            }
        }
    }

    // Print shortest distances from start to all vertices
    cout << "Shortest paths from " << start << ":" << endl;
    for(int i = 0; i < maxVertices; i++) {
        if(dist[i] == INF) {
            cout << char('A' + i) << ": Unreachable" << endl;
        } else {
            cout << char('A' + i) << ": " << dist[i] << endl;
        }
    }

    delete[] dist;
}