#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <string>
#include <iomanip>
#include <queue>
#include <stack>
//#include sqll.h  // for traversals

using namespace std;


//undirected weighed graph
struct edge
{
    struct vertex* dest;
    edge* eNext;

    int weight;
};

struct vertex
{
    char data;
    vertex* vNext;
    edge* aHead;
};

class Graph
{
    private:
        vertex* vertices; // list of vertices
        int** adjMatrix;
        bool* visited;
        int maxVertices;
        int numVertices;

        // DSU arrays for Union-Find
        int* parent;
        int* rank;

        // Helper functions for traversals
        void dfsLRecursive(vertex* v);
        bool detectCycleUtil(vertex* v, vertex* parent);

        // DSU helper functions
        int find(int x);
        void unionSets(int x, int y);

    public:
        Graph(int maxV);
        ~Graph();

        //core operations
        void addVertex(char data);
        void addEdge(char src, char dest, int weight);
        void removeVertex(char data);
        void removeEdge(char src, char dest); //source and destination, so simple flat edge list
        
        // traversal algorithms
        void bfsL(char start);
        void bfsM(char start);
        void dfsL(char start);
        void dfsM(char start);

        // display
        void displayList();
        void displayMatrix();

        void detectCycle();
        void prim(char start);
        void kruskal();
        void dijkstra(char start);

};

#endif